import numpy as np

class SVD:
    """ Singular Value Decomposition model for recommendation. """
    def __init__(self, train_path, test_path, lr=0.1, lamda_factors=(0.01, 0.01, 0.01, 0.01), factor=50):
        self.train_path = train_path
        self.test_path = test_path
        self.lr = lr
        self.lamda1, self.lamda2, self.lamda3, self.lamda4 = lamda_factors
        self.factor = factor
        self.node_idx = self.indices()
        self.train_user_data, self.train_item_data = self.train_data()
        self.train_data, self.valid_data = self.split_data()
        self.test_data = self.test_data()
        self.bx = np.zeros(len(self.train_user_data), dtype=np.float64)
        self.bi = np.zeros(len(self.train_item_data), dtype=np.float64)
        self.average = self.all_average()
        self.Q = np.random.normal(0, 0.1, (self.factor, len(self.bi)))
        self.P = np.random.normal(0, 0.1, (self.factor, len(self.bx)))

    def indices(self):
        """ Extracts unique item indices from the training data. """
        all_nodes = set()
        with open(self.train_path, 'r') as f:
            for line in f:
                if '|' in line:
                    _, num = map(int, line.strip().split('|'))
                    for _ in range(num):
                        item_id = int(f.readline().strip().split()[0])
                        all_nodes.add(item_id)
        return {node: idx for idx, node in enumerate(sorted(all_nodes))}

    def train_data(self):
        """ Retrieves training data and maps item IDs to their indices. """
        data_user, data_item = {}, {}
        with open(self.train_path, 'r') as f:
            for line in f:
                if '|' in line:
                    user_id, num = map(int, line.strip().split('|'))
                    for _ in range(num):
                        item_id, score = map(float, f.readline().strip().split())
                        if user_id not in data_user:
                            data_user[user_id] = []
                        if self.node_idx[int(item_id)] not in data_item:
                            data_item[self.node_idx[int(item_id)]] = []
                        data_user[user_id].append([self.node_idx[int(item_id)], score / 100])
                        data_item[self.node_idx[int(item_id)]].append([user_id, score / 100])
        return data_user, data_item

    def test_data(self):
        """ Retrieves test data, listing items for each user. """
        data = {}
        with open(self.test_path, 'r') as f:
            for line in f:
                if '|' in line:
                    user_id, num = map(int, line.strip().split('|'))
                    for _ in range(num):
                        item_id = int(f.readline().strip())
                        if user_id not in data:
                            data[user_id] = []
                        data[user_id].append(item_id)
        return data


    def split_data(self, ratio=0.85, shuffle=True):
        """ Splits user data into training and validation sets. """
        train_data, valid_data = {}, {}
        
        for user_id, items in self.train_user_data.items():
            if user_id not in train_data:
                train_data[user_id] = []
            if user_id not in valid_data:
                valid_data[user_id] = []
                
            if shuffle:
                np.random.shuffle(items)
                
            split_point = int(len(items) * ratio)
            train_data[user_id] = items[:split_point]
            valid_data[user_id] = items[split_point:]
        
        return train_data, valid_data

    def all_average(self):
        """ Computes the global mean of scores. """
        total_score = sum(score for items in self.train_user_data.values() for _, score in items)
        total_count = sum(len(items) for items in self.train_user_data.values())
        return total_score / total_count

    def predict(self, user_id, item_id):
        """ Predicts the score for a given user and item. """
        return (self.average + self.bx[user_id] + self.bi[item_id] +
                np.dot(self.P[:, user_id], self.Q[:, item_id]))

    def loss(self, is_valid=False):
        """ Computes the loss for training or validation data. """
        data = self.valid_data if is_valid else self.train_data
        total_loss = sum((score - self.predict(user_id, item_id)) ** 2
                         for user_id, items in data.items() for item_id, score in items)
        regularizers = (self.lamda1 * np.sum(self.P ** 2) + self.lamda2 * np.sum(self.Q ** 2) +
                        self.lamda3 * np.sum(self.bx ** 2) + self.lamda4 * np.sum(self.bi ** 2))
        return (total_loss + regularizers)*100 / sum(len(items) for items in data.values())

    def rmse(self):
        errors = []
        for user_id, items in self.train_user_data.items():
            for item_id, score in items:
                prediction = self.predict(user_id, item_id)
                errors.append((score - prediction) ** 2)
        mean_squared_error = np.mean(errors)
        return np.sqrt(mean_squared_error)*100
    
    def update_parameters(self, user_id, items):
        for item_id, score in items:
            error = score - self.predict(user_id, item_id)
            self.bx[user_id] += self.lr * (error - self.lamda3 * self.bx[user_id])
            self.bi[item_id] += self.lr * (error - self.lamda4 * self.bi[item_id])
            self.P[:, user_id] += self.lr * (error * self.Q[:, item_id] - self.lamda1 * self.P[:, user_id])
            self.Q[:, item_id] += self.lr * (error * self.P[:, user_id] - self.lamda2 * self.Q[:, item_id])
            
    def train(self, epochs=20, patience=3, min_delta=0.01):
        print('训练已开始')
        best_train_loss = float('inf')
        best_valid_loss = float('inf')
        no_improvement_count = 0

        for epoch in range(epochs):
            for user_id, items in self.train_data.items():
                self.update_parameters(user_id, items)
            train_loss = self.loss()
            valid_loss = self.loss(is_valid=True)
            current_rmse = self.rmse()
            print(f'Epoch: {epoch + 1} train loss: {train_loss:.6f} valid loss: {valid_loss:.6f} RMSE: {current_rmse:.6f}')

            # Check if both train and valid losses have not improved significantly
            if (abs(best_train_loss - train_loss) < min_delta and
                abs(best_valid_loss - valid_loss) < min_delta):
                no_improvement_count += 1
            else:
                no_improvement_count = 0

            best_train_loss = min(best_train_loss, train_loss)
            best_valid_loss = min(best_valid_loss, valid_loss)

            if no_improvement_count >= patience:
                print(f'早停在第 {epoch + 1} 轮，训练和验证损失都没有显著改善')
                break

        print('训练已完成')

    def write_result(self, predict_score, write_path):
        """ Writes the prediction scores to the specified file path. """
        with open(write_path, 'w') as f:
            for user_id, items in predict_score.items():
                f.write(f'{user_id}|{len(items)}\n')  # Dynamically count items instead of hardcoding
                for item_id, score in items:
                    f.write(f'{item_id} {score:.2f}\n')  # Format score to two decimal places
        print('已写入结果文件')
        
    def calculate_adjusted_score(self, user_id, item_id):
        """ Calculate and adjust the predicted score within the allowed range. """
        if item_id not in self.node_idx:
            pre_score = self.average * 100
        else:
            new_id = self.node_idx[item_id]
            pre_score = self.predict(user_id, new_id) * 100
            pre_score = max(0.0, min(100.0, pre_score))  # Clamping the score between 0 and 100
        return pre_score
    
    def test(self, write_path='result.txt'):
        """ Tests the model by predicting scores for the test dataset and optionally writing the results. """
        print('开始进行评分预测')
        predict_score = {}
        for user_id, item_list in self.test_data.items():
            if user_id not in predict_score:
                predict_score[user_id] = []
            for item_id in item_list:
                pre_score = self.calculate_adjusted_score(user_id, item_id)
                predict_score[user_id].append((item_id, pre_score))
        print('评分预测完成')
        if write_path:
            self.write_result(predict_score, write_path)  
        return predict_score

if __name__ == '__main__':
    train_path = 'train.txt'
    test_path = 'test.txt'
    svd = SVD(train_path, test_path)
    svd.train(epochs=50)
    svd.test(write_path='result.txt')
    rmse = svd.rmse()
    print(f'RMSE: {rmse:.6f}')