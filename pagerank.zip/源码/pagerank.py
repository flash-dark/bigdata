from collections import defaultdict
import time

class PageRank:
    def __init__(self, beta=0.85, ranknum=100, input_file='Data.txt', output_file='Result1.txt'):
        self.beta = beta  # 阻尼系数，代表页面之间链接的重要性
        self.ranknum = ranknum  # 输出排名前n的页面
        self.input_file = input_file  # 输入文件路径
        self.output_file = output_file  # 输出文件路径
        self.graph = defaultdict(set)  # 存储图的邻接表
        self.node_rank = {}  # 存储每个节点的PageRank值

    def load_data(self):
        # 从文件中读取图数据，构建邻接表
        with open(self.input_file, 'r') as file:
            for line in file:
                from_node, to_node = map(int, line.strip().split())
                self.graph[from_node].add(to_node)
                self.graph[to_node]  # 确保to_node在图中，即使它没有出边

        # 初始化每个节点的PageRank值
        for node in self.graph:
            self.node_rank[node] = 1.0 / len(self.graph)

    def update_rank(self, old_rank, new_rank):
        n = len(self.graph)  # 节点总数
        base_rank = (1 - self.beta) / n  # 每个节点由于随机跳转获得的基础PageRank值
        for node in self.graph:
            out_degree = len(self.graph[node])
            if out_degree > 0:
                for neighbor in self.graph[node]:
                    new_rank[neighbor] += self.beta * (old_rank[node] / out_degree)
            new_rank[node] += base_rank  # 添加随机跳转的PageRank值

    def page_rank(self, threshold=1e-6):
        # 执行所有迭代，直到收敛
        while True:
            old_rank = self.node_rank.copy()
            new_rank = defaultdict(float)
            self.update_rank(old_rank, new_rank)
            # 为处理dead ends，重新分配丢失的PageRank值
            total_rank = sum(new_rank.values())
            missing_rank = (1.0 - total_rank) / len(self.graph)
            for node in new_rank:
                new_rank[node] += missing_rank
            # 计算两次迭代之间的PageRank值的变化
            diff = sum(abs(new_rank[node] - old_rank[node]) for node in self.graph)
            if diff < threshold:
                break
            self.node_rank = new_rank.copy()

    def save(self):
        # 将最终的PageRank值排序并保存到文件
        sorted_nodes = sorted(self.node_rank.items(), key=lambda x: x[1], reverse=True)
        with open(self.output_file, 'w') as file:
            for i, (node, rank) in enumerate(sorted_nodes):
                if i >= self.ranknum:
                    break
                file.write(f'{node} {rank:.10f}\n')

    def running(self):
        # 处理数据，执行PageRank计算，并保存结果
        self.load_data()
        start_time = time.time()
        self.page_rank()
        end_time = time.time()
        time_ms = (end_time - start_time) * 1000  # 将秒转换为毫秒
        print(f"已完成PageRank，结果见.txt文件，PageRank计算时间: {time_ms:.2f}毫秒")
        self.save()

def main():
    pr = PageRank(beta=0.85, ranknum=100, input_file='Data.txt', output_file='Result1.txt')
    pr.running()

if __name__ == '__main__':
    main()