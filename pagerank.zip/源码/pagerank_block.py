from collections import defaultdict
import time

class PageRank:
    def __init__(self, beta=0.85, block_num=5, epsilon=1.0e-6, ranknum=100, input_file='Data.txt', output_file='Result2.txt'):
        self.beta = beta  # Damping factor
        self.block_num = block_num  # 使用更多的块来提高效率
        self.epsilon = epsilon  # 收敛阈值
        self.ranknum = ranknum
        self.input_file = input_file
        self.output_file = output_file
        self.graph = defaultdict(set)
        self.node_rank = {}
        self.blocks = []

    def load_data(self):
        with open(self.input_file, 'r') as file:
            for line in file:
                from_node, to_node = map(int, line.strip().split())
                self.graph[from_node].add(to_node)
                self.graph[to_node]  # 确保to_node在图中

        n = len(self.graph)
        nodes_per_block = n // self.block_num + (1 if n % self.block_num > 0 else 0)
        nodes = list(self.graph.keys())
        
        # 初始化每个块的节点集合
        for i in range(0, n, nodes_per_block):
            self.blocks.append(nodes[i:i+nodes_per_block])

        for node in self.graph:
            self.node_rank[node] = 1.0 / n

    def update_rank_block(self, block_nodes, old_rank, new_rank):
        n = len(self.graph)
        for node in block_nodes:
            out_degree = len(self.graph[node])
            if out_degree > 0:
                share = self.beta * (old_rank[node] / out_degree)
                for neighbor in self.graph[node]:
                    new_rank[neighbor] += share
            # 添加随机跳转的PageRank值
            new_rank[node] += (1 - self.beta) / n

    def iterator(self):
        old_rank = self.node_rank.copy()
        new_rank = defaultdict(float)
        n = len(self.graph)

        for block_nodes in self.blocks:
            self.update_rank_block(block_nodes, old_rank, new_rank)

        # 重新分配丢失的rank（由于dead ends）并考虑随机跳转
        total_rank = sum(new_rank.values())
        missing_rank = (1 - total_rank) / n
        for node in new_rank:
            new_rank[node] += missing_rank

        self.node_rank = new_rank

    def page_rank(self):
        while True:
            old_rank = self.node_rank.copy()
            self.iterator()
            # 计算所有节点排名的变化
            diff = sum(abs(old_rank[node] - self.node_rank[node]) for node in self.node_rank)
            if diff < self.epsilon:
                break  # 如果变化小于epsilon，则认为已经收敛

    def save(self):
        sorted_nodes = sorted(self.node_rank.items(), key=lambda x: x[1], reverse=True)
        with open(self.output_file, 'w') as file:
            for i, (node, rank) in enumerate(sorted_nodes):
                if i >= self.ranknum:
                    break
                file.write(f'{node} {rank:.10f}\n')

    def running(self):
        self.load_data()
        start_time = time.time()
        self.page_rank()
        end_time = time.time()
        time_ms = (end_time - start_time) * 1000  # 将秒转换为毫秒
        print(f"已完成PageRank，结果见.txt文件，PageRank计算时间: {time_ms:.2f}毫秒")
        self.save()

def main():
    pr = PageRank(beta=0.85, block_num=5, epsilon=1.0e-6, ranknum=100)
    pr.running()

if __name__ == '__main__':
    main()